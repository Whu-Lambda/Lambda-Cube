
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
interface BinaryIntToInt {
    public int binOp(int lhs, int rhs);
}
interface IntIntToInt{
    public int binOp(int lhs, int rhs);
}
class IntArrayUtil {
    public static int foldLeft(int[] array, int init, BinaryIntToInt func) {
        int acc = init;
        for (int elem : array) {
            acc = func.binOp(acc, elem);
        }
        return acc;
    }
}

class Bar {
    public int elem;

    Bar(int elem) {
        this.elem = elem;
    }

    @Override
    public String toString() {
        return Integer.valueOf(elem).toString();
    }
}


public class JavaKlazz {

    public static void main(String[] args) {
        // Integer res = foo(null,null);
        // Integer res1 = foo1(null,null);


        Bar result = new Bar(0);
        Bar[] barArr = new Bar[]{
                new Bar(1),
                new Bar(2),
                new Bar(3),
                new Bar(4),
                new Bar(5)
        };
        accumulateBar(barArr, barArr[0]);

        System.out.print("the result is:");
        System.out.println(barArr[0]);
        System.out.print("result of array after accumulate:");
        System.out.println(Arrays.toString(barArr));


        int[] arr = new int[]{1, 2, 3, 4, 5};
        int fold1 = IntArrayUtil.foldLeft(arr, 0, new BinaryIntToInt() {
            @Override
            public int binOp(int lhs, int rhs) {
                return lhs + rhs;
            }
        });
        int fold2 = IntArrayUtil.foldLeft(arr, 1, new BinaryIntToInt() {
            @Override
            public int binOp(int lhs, int rhs) {
                return lhs * rhs;
            }
        });
        System.out.println(fold1);
        System.out.println(fold2);


        int fold3 = IntArrayUtil.foldLeft(arr, 0, (acc, elem) -> acc + elem);
        int fold4 = IntArrayUtil.foldLeft(arr, 1, (acc, elem) -> acc * elem);
        System.out.println(fold3);
        System.out.println(fold4);
    }

    private static void accumulateBar(Bar[] barArr, Bar result) {
        for (Bar elem : barArr) {
            result.elem += elem.elem;
        }
    }


    public static Integer foo(Integer lhs, Integer rhs) {
        return lhs + rhs;
    }

    public static Integer foo0(Integer lhs, Integer rhs) {
        if (lhs != null) {
            if (rhs != null)
                return lhs + rhs;
        }
        return null;
    }

    public static Integer foo1(@NotNull Integer lhs, @NotNull Integer rhs) {
        return lhs + rhs;
    }


    public static String weight(int w) {
        String res;
        if (w > 70) {
            res = "too fat";
        } else if (w > 40) {
            res = "overweight";
        } else if (w > 30) {
            res = "normal";
        } else {
            res = "too light";
        }
        return res;
    }
}
