fun main(args: Array<String>) {
    println("Hello World!")
    var nullableStr:String? = null
    val lenOfNullableStr = nullableStr?.length
    val b:String? = "Kotlin"
    if(!b.isNullOrEmpty()){
        println("${b.length}")
    }else{
        println("empty")
    }
    val ifExpr = if(!b.isNullOrEmpty()){
        "2333"
    }else{
        "hhhh"
    }
    val whenExpr = when{
        b.isNullOrEmpty() -> "null"
        else -> b
    }
    val arr = intArrayOf(1,2,3)
    arr.myFoldLeft(0){l,r -> l + r}
    arr.myFoldLeft(0,object:(Int,Int) -> Int{
        override fun invoke(p1: Int, p2: Int): Int {
           return p1 + p2
        }
    })
    // Try adding program arguments via Run/Debug configuration.
    // Learn more about running applications: https://www.jetbrains.com/help/idea/running-applications.html.
    println("Program arguments: ${args.joinToString()}")
}

fun foo(lhs:Int,rhs:Int):Int = lhs + rhs
fun IntArray.myFoldLeft(init:Int,func:(Int,Int) -> Int):Int{
    var acc = init
    for(elem in this){
        acc = func(acc,elem)
    }
    return acc
}