
rootProject.name = "whynotkt"

